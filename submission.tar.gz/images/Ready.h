/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 Ready Ready.png 
 * Time-stamp: Wednesday 11/10/2021, 10:11:31
 * 
 * Image Information
 * -----------------
 * Ready.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef READY_H
#define READY_H

extern const unsigned short Ready[38400];
#define READY_SIZE 76800
#define READY_LENGTH 38400
#define READY_WIDTH 240
#define READY_HEIGHT 160

#endif

