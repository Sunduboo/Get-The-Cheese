/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 Mouse Mouse.png 
 * Time-stamp: Wednesday 11/10/2021, 10:08:41
 * 
 * Image Information
 * -----------------
 * Mouse.png 21@21
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MOUSE_H
#define MOUSE_H

extern const unsigned short Mouse[441];
#define MOUSE_SIZE 882
#define MOUSE_LENGTH 441
#define MOUSE_WIDTH 21
#define MOUSE_HEIGHT 21

#endif

