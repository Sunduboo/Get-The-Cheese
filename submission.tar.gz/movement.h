#ifndef MOVEMENT_H
#define MOVEMENT_H

void moveMouse(int *row, int speedR, int *col, int speedC, int width, int height);
#endif