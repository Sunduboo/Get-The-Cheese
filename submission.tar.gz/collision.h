#ifndef COLLISION_H
#define COLLISION_H

int collisionWall(int mouseRow, int mouseCol, int mouseWidth, int mouseHeight);
int collisionCheese(int mouseRow, int mouseCol, int mouseWidth, int mouseHeight);

#endif